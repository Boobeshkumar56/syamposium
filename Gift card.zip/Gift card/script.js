// Scene setup
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(45, 500 / 700, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ alpha: true });
renderer.setSize(450, 500);
document.getElementById('left-side').appendChild(renderer.domElement);

// Load GLTF 3D Rocket Model
const loader = new THREE.GLTFLoader();
let rocket;

loader.load('models/rocket.glb', function (gltf) {
    rocket = gltf.scene;
    rocket.scale.set(2, 2, 2);  // Adjust rocket size
    rocket.position.y = -1;  // Center the model
    scene.add(rocket);
}, undefined, function (error) {
    console.error("Error loading the model:", error);
});

// Lighting
const light = new THREE.PointLight(0xffffff, 1, 100);
light.position.set(5, 5, 5);
scene.add(light);

// Camera Position
camera.position.z = 6;

// Hover Animation (Tilt Effect)
document.querySelector(".card-container").addEventListener("mousemove", (event) => {
    let x = (event.clientX / window.innerWidth) * 2 - 1;
    let y = -(event.clientY / window.innerHeight) * 2 + 1;
    if (rocket) {
        rocket.rotation.y = x * 0.5;
        rocket.rotation.x = y * 0.5;
    }
});

// Animation Loop
function animate() {
    requestAnimationFrame(animate);
    if (rocket) {
        rocket.rotation.y  += 0.005;  // Slow auto-rotation
    }
    renderer.render(scene, camera);
}
animate();
